<?php
require_once "controladores/accesos_CO.php";

$accesos_CO = new accesos_CO();
$accesos_CO->cerrarSesion();
?>