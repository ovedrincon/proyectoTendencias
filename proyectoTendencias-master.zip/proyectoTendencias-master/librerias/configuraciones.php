<?php
///////////////////Conexión a la Base de Datos
session_name("NOMBRE_DE_LA_EMPRESA");
session_start();
const IP_MAQUINA="sql102.epizy.com";
const BASE_DE_DATOS="epiz_26961084_paracial";

const USUARIO_ADMINISTRADOR="epiz_26961084";
const CLAVE_ADMINISTRADOR="qUL3ccMAl2OZB";

const USUARIO_LIMITADO="";
const CLAVE_LIMITADO="";
////////////////////////////////////////////////
?>